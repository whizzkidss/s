/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam;

/**
 *
 * @author Redi
 */
public class Punonjes {
    private int id;
    private String emer;
    private String mbiemer;
    private String roli;
    private double paga;

    public Punonjes(int id, String emer, String mbiemer, String roli, double paga) {
        this.id = id;
        this.emer = emer;
        this.mbiemer = mbiemer;
        this.roli = roli;
        this.paga = paga;
    }

    public Punonjes() {
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmer() {
        return emer;
    }

    public void setEmer(String emer) {
        this.emer = emer;
    }

    public String getMbiemer() {
        return mbiemer;
    }

    public void setMbiemer(String mbiemer) {
        this.mbiemer = mbiemer;
    }

    public String getRoli() {
        return roli;
    }

    public void setRoli(String roli) {
        this.roli = roli;
    }

    public double getPaga() {
        return paga;
    }

    public void setPaga(double paga) {
        this.paga = paga;
    }

    @Override
    public String toString() {
        return "Punonjes{" + "id=" + id + ", emer=" + emer + ", mbiemer=" + mbiemer + ", roli=" + roli + ", paga=" + paga + '}';
    }
    
    
}
