/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam;

import java.util.ArrayList;

/**
 *
 * @author Redi
 */
public class ListePagesash{
    private int id;
    private ArrayList<Punonjes> listePunonjesish;
    private double totali;

    public ListePagesash(int id, ArrayList<Punonjes> listePunonjesish) {
        this.id = id;
        this.listePunonjesish = listePunonjesish;
    }

    public ListePagesash() {
    }
    
    public int getId() {
        return id;
    }
    
    private double Bonus(double total){
        if(total < 10000){
            return total + (total * 0.06);
        }else if(total >= 10000 && total <=20000){
            return total + (total * 0.04); 
        }
        return total;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Punonjes> getListePunonjesish() {
        return listePunonjesish;
    }

    public void setListePunonjesish(ArrayList<Punonjes> listePunonjesish) {
        this.listePunonjesish = listePunonjesish;
    }

    public double getTotali() {
        double total = 0;
        for (int i = 0; i < listePunonjesish.size(); i++) {
            total += listePunonjesish.get(i).getPaga();
        }
        return Bonus(total);
    }

    public void setTotali(double totali) {
        this.totali = totali;
    }
    
    @Override
    public String toString() {
        return "ListePagesash{" + "id=" + id + ", listePunonjesish=" + listePunonjesish + ", totali=" + totali + '}';
    }
    
}
