/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam;

import java.util.ArrayList;

/**
 *
 * @author Redi
 */
public class ListaShtese {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Punonjes p = new Punonjes(0, "redon", "Kallaverja", "Manager", 10000);
        Punonjes p1 = new Punonjes(1, "sara", "kullolli", "Employee", 10000);
        Punonjes p3 = new Punonjes(1, "filan", "fisteku", "Employee", 210);
        
        ArrayList<Punonjes> p2 = new ArrayList<>();
        p2.add(p);
        p2.add(p1);
        p2.add(p3);
        
        ListePagesash lp = new ListePagesash(0, p2);
        
        ListePaga(p2);
        
    
    }
    private static void ListePaga(ArrayList<Punonjes> p){
        System.out.println("Punonjesit me page me pak se 220 jana si me poshte:");
        for (int i = 0; i < p.size(); i++) {
            if (p.get(i).getPaga() < 220){
                System.out.println(p.get(i).getEmer() + " " + p.get(i).getMbiemer());
            }
        }
        
    } 
    
}
